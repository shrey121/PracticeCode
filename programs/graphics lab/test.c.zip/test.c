#include<OpenGL/gl.h>
#include<OpenGL/glu.h>
#include<GLUT/glut.h>
#include <math.h>
#include<stdio.h>
#include<stdlib.h>

float limit=0;
float llimit=0;
float len=5;
int flag=0;
void init(void)
{
    glClearColor(0.0,0.0,0.0,0.0);
    glMatrixMode(GL_PROJECTION);
    gluOrtho2D(0.0,300.0,0.0,300.0);    
}

void circle (int x,int y)
{
    float tx,ty;
    float i;
    float a=0,b=0;
    glBegin(GL_LINE_STRIP);
    for(int j=0.;j<llimit;j++)
    {
        for (i = 0; i < len; i=i+.09999)
        {
            if(flag%3 == 1)
            {
                a=a+.2;
                b=b+.2;
                tx=x+b;
                ty=y;
            }
            if(flag%3 == 2)
            {
                a=a+.2;
                b=b+.2;
                tx=x-b/2;
                ty=y+b/1.73;
            }
            if(flag%3 == 0)
            {
                a=a+.2;
                b=b+.2;
                tx=x-b/2;
                ty=y-b/1.73;
            }
            glVertex2f(tx,ty);
        }
        flag++;
    }
    glEnd();
}

void draw(void)
{
    glClear(GL_COLOR_BUFFER_BIT);
    glColor3f(0,1,0);
    circle(150,150);
    glFlush();
}

void keyPressed(int key,int x,int y)
{
    printf("%d  %d\n",x,y);
    if(key==GLUT_KEY_UP)
    {
        llimit=llimit+0.1;
        circle(250,250);
    }
    if(key==GLUT_KEY_DOWN)
    {
        llimit=llimit-.1;
        circle(250,250);
    }
    glutPostRedisplay();
}

int main(int argc, char**argv)
{
    glutInit(&argc, argv);  
    glutInitWindowPosition(10,10);
    glutInitWindowSize(500,500);
    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
    glutCreateWindow("Triangle");
    init();
    glutDisplayFunc(draw);
    glutSpecialFunc(keyPressed);
    glutMainLoop();    
}

